<?php
 $connection = mysqli_connect("localhost","root","","women-cell");
if(mysqli_connect_error()){
    echo "cannotconnect";

}
?>